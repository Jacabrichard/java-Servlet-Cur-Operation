
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.IOException;
import java.io.PrintWriter;

import FirstServelet.Emp;
import FirstServelet.EmpDao;

@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>Update Employee</h1>");
		String sid = request.getParameter("id");
		int id = Integer.parseInt(sid);
		Emp e = EmpDao.getEmployeeById(id);
		out.println(
				"<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css\" rel=\"stylesheet\">");
		out.print("<div class='container'>");
		out.println("<div class='border border-dark p-5'>");
		out.println("<form action='EditServlet2' method='post'>");
		out.println("<input type='hidden' name='id' value='" + e.getId() + "'/>");
		out.println("<div class='form-group'>");
		out.println("<label for='name'>Name:</label> ");
		out.println(
				"<input type='text'class='form-control' id='name' name='name' value='" + e.getName() + "' required>");
		out.println("</div>");
		out.println("<div class='form-group'>");
		out.println("<label for='email'>Email:</label>");
		out.println("<input type='email'class='form-control' id='email' name='email'   value='" + e.getEmail()
				+ "'  required>");
		out.println("<div class='form-group'>");
		out.println("<label for='pwd'>Password:</label>");
		out.println("<input type='password'class='form-control' id='pwd' name='password' value='" + e.getPassword()
				+ "' required>");
		out.println("<div class='form-group'>");
		out.println("<label for='Country'>Country:</label>");
		out.println(" <select name='country'class='form-select'>");
		out.println("<option>India</option>");
		out.println("<option>USA</option>");
		out.println("<option>UK</option>");
		out.println("<option>Other</option>");
		out.println("</select>");
		out.println("</div>");
		out.println("<div class='form-group pt-5'>");
		out.println("<input type='submit' class='btn btn-primary' value='Edit & Save '/>");
		out.println("</div>");
		out.println("</form>");
		out.println("</div>");
		out.println("</div>");
		out.close();
	}
}
