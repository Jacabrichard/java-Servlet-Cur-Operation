import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import FirstServelet.Emp;
import FirstServelet.EmpDao;

@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println(
				"<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css\" rel=\"stylesheet\">");
		out.println("<div class='container'>");
		out.println("<h1>Employees List</h1>");
		out.println("<a href='index.html' class='btn btn-primary mb-3'>Add New Employee</a>");
		List<Emp> list = EmpDao.getAllEmployees();
		out.print("<table class='table table-striped table-bordered' width='100%'");
		out.print(
				"<tr><th>ID</th><th>NAME</th><th>PASSWORD</th><th>EMAIL</th><th>COUNTRY</th><th>EDIT</th><th>DELETE</th></tr>");
		for (Emp e : list) {
			out.print("<tr><td>" + e.getId() + "</td><td>" + e.getName() + "</td><td>" + e.getPassword()
					+ "</td>   <td>" + e.getEmail() + "</td><td>" + e.getCountry()
					+ "</td><td><a class='btn btn-primary' href='EditServlet?id=" + e.getId()
					+ "'>edit</a></td><td><a class='btn btn-danger' href='DeleteServlet?id=" + e.getId()
					+ "'>delete</a></td></tr>");
		}
		out.print("</table>");
		out.println("</div>");
		out.close();
	}
}